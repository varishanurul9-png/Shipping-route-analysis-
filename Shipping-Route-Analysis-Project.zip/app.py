import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
import matplotlib.pyplot as plt

st.set_page_config(page_title="Shipping Route Efficiency Analysis", layout="wide")
st.title("Factory-to-Customer Shipping Route Efficiency Analysis")

uploaded_file = st.file_uploader("Upload Shipping Dataset (CSV)", type=["csv"])

if uploaded_file is not None:
    df = pd.read_csv(uploaded_file)
    st.dataframe(df.head())

    X = df[["Distance_km","Traffic_Level","Fuel_Cost"]]
    y = df["Delivery_Time_hr"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    st.write("MAE:", mean_absolute_error(y_test, predictions))

    distance = st.number_input("Distance (km)", value=100.0)
    traffic = st.slider("Traffic Level", 1, 10, 5)
    fuel = st.number_input("Fuel Cost", value=50.0)

    if st.button("Predict"):
        pred = model.predict(pd.DataFrame({
            "Distance_km":[distance],
            "Traffic_Level":[traffic],
            "Fuel_Cost":[fuel]
        }))
        st.success(f"Estimated Delivery Time: {pred[0]:.2f} hr")
