# Shipping Route Analysis

Machine Learning based shipping route efficiency analysis system for Nassau Candy Distributor.

Files:
- app.py
- requirements.txt
- dataset.csv

Run:
streamlit run app.py
